const BACKEND = "https://ai-secured-training-dashboard.onrender.com";

const params = new URLSearchParams(window.location.search);
const user = params.get("user");

if (!user) {
  alert("No user found in URL");
}

// --------- Chart ----------
const ctx = document.getElementById("marketChart");

if (ctx) {
  new Chart(ctx, {
    type: "line",
    data: {
      labels: ["Mon", "Tue", "Wed", "Thu", "Fri"],
      datasets: [{
        label: "NIFTY 50",
        data: [24100, 24250, 24310, 24480, 24510],
        borderWidth: 2,
        tension: 0.4,
      }]
    },
    options: {
      plugins: { legend: { display: false } }
    }
  });
}

// --------- Session / Risk Banner ----------
fetch(`${BACKEND}/session?username=${user}`)
  .then(res => res.json())
  .then(data => {
    if (data.access === "PARTIAL") {
      document.getElementById("securityBanner").innerHTML = `
        <div class="alert">
          ⚠ New device detected. Portfolio access is locked until verification.
        </div>
      `;
    }
  });

// --------- Portfolio ----------
fetch(`${BACKEND}/portfolio?username=${user}`)
  .then(res => res.json())
  .then(data => {
    const box = document.getElementById("portfolioContent");

    if (data.locked) {
      box.innerHTML = `
        <div class="blur">
          <p><b>Balance:</b> ₹4,25,000</p>
          <p><b>Holdings:</b> INFY, TCS, RELIANCE</p>
          <p><b>Last trade:</b> BUY INFY</p>
        </div>

        <div class="overlay">
          <p>New device / risky login detected</p>
          <button onclick="verify()">Verify to Unlock</button>
        </div>
      `;
    } else {
      box.innerHTML = `
        <p><b>Balance:</b> ₹4,25,000</p>
        <p><b>Holdings:</b> INFY, TCS, RELIANCE</p>
        <p><b>Last trade:</b> BUY INFY</p>
      `;
    }
  })
  .catch(() => {
    document.getElementById("portfolioContent").innerText =
      "Unable to load portfolio";
  });

function verify() {
  window.location.href = `verify.html?user=${user}`;
}

function logout() {
  window.location.href = "landing.html";
}
