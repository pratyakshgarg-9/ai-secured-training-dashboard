users = {}
sessions = {}
otp_tracker = {}
login_history = []
